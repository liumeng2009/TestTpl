package com.meng.plugin.pushservice;

public class Constants {
    public static final String CHAT_SERVER_URL = "http://liumeng.iego.cn";
}
